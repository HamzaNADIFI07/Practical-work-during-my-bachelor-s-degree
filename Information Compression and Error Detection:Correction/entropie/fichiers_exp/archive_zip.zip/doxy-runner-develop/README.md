doxy-runner       {#README}
=============================
[TOC]

# 概要
doxygen と PlantUML を実行する Linux コンテナ

GitLab Runner での CI/CD で 利用されることを想定しています.